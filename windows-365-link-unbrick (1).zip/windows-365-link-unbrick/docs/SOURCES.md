# Sources

Reviewed October 4, 2026. The supplied text attachments contained the first two URLs, not article snapshots.

1. [Microsoft Learn: Wipe or reset Windows 365 Link](https://learn.microsoft.com/en-us/windows-365/link/wipe-reset-windows-365-link) — primary recovery authority; page updated September 13, 2026.
2. [Dieter Kempeneers: Windows 365 Link bare-metal recovery](https://kempeneers.eu/2026/07/23/windows-365-link-bare-metal-recovery/) — July 23, 2026 community walkthrough; contextual observations.
3. [Microsoft Support: Create and use a USB recovery drive](https://support.microsoft.com/en-US/surface/drivers-firmware/creating-and-using-a-usb-recovery-drive-for-surface) — USB preparation reference linked by source 1.
4. [Microsoft Learn: Manage Link firmware settings](https://learn.microsoft.com/en-us/windows-365/link/manage-firmware-settings) — UEFI entry and boot selection reference linked by source 1.

## Resolving differences

- The older walkthrough uses two power disconnections. This guide follows Microsoft's newer power-button sequence or its firmware entry procedure.
- The walkthrough describes packages as identical. Microsoft clarifies that overlapping languages work in either package, while the complete language sets differ.
- The walkthrough reports a roughly 5.3 GB image and uses a 32 GB USB. These are observations, not guaranteed current image size or minimum capacity.
- The walkthrough reports unsuccessful Startup Repair in its testing. That does not establish a universal failure.
- Microsoft's BMR instructions take priority if screens or procedures change.

The prose is an original summary. Source articles, Microsoft recovery images, and third-party screenshots are not redistributed. No physical recovery success is claimed.
